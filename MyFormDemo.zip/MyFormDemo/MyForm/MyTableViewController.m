//
//  MyTableViewController.m
//  MyForm
//
//  Created by guolin     song on 2017/3/29.
//  Copyright © 2017年 eastraycloud. All rights reserved.
//

#import "MyTableViewController.h"
#import "FormTableViewCell.h"

#import "TextFiledForm.h"
@interface MyTableViewController ()<FormTableViewDelegate>
@property (nonatomic,strong) NSMutableArray * dataSource;
@end

@implementation MyTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
 
    self.dataSource=[NSMutableArray array];
    
    
    

    for (int i=0; i<15; i++) {
        FormModel * model1=[FormModel new];
        model1.cellHeight=60.f;
        model1.placeholder=[self getPlaceholderWithType:i];
        model1.content=nil;
        model1.formCellViewType=FormCellViewType_TF;
        model1.formTextFieldType=i;
        model1.showTitle=YES;
        
        [self.dataSource addObject:model1];
    }
    
    
    FormModel * model12=[FormModel new];
    model12.cellHeight=60.f;
    model12.placeholder=@"这是文本输入";
    //注意 model12.content=@"";
    model12.content=@"";
    model12.showTitle=YES;
    model12.formCellViewType=FormCellViewType_TV;
    [self.dataSource addObject:model12];
    
    
    [self.tableView reloadData];
    

}
-(NSString *)getPlaceholderWithType:(NSInteger)type
{

    if (type==0) {
        return @"0-无限制";
    }
    if (type==1) {
        return @"1-纯英文";
    }
    if (type==2) {
        return @"2-纯中文";
    }
    if (type==3) {
        return @"3-纯数字";
    }
    if (type==4) {
        return @"4-小数";
    }
    if (type==5) {
        return @"5-手机号码";
    }
    if (type==6) {
        return @"6-邮箱";
    }
    if (type==7) {
        return @"7-中文或英文";
    }
    if (type==8) {
        return @"8-英文或数字";
    }
    if (type==9) {
        return @"9-中文和英文";
    }
    if (type==10) {
        return @"10- 英文和数字";
    }
    if (type==11) {
        return @"11-日期";
    }
    if (type==12) {
        return @"12-密码";
    }
    if (type==13) {
        return @"13-url";
    }
    if (type==14) {
        return @"14-不可用的TF";
    }
    
    return @"未知";
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    FormModel * model=[self.dataSource objectAtIndex:indexPath.row];
    NSString * idenfireCell=[FormTableViewCell cellIdentifierForMessageModel:model];
   
    FormTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:idenfireCell ];
    
    
    if (!cell) {
        
        cell=[[FormTableViewCell alloc] initWithFormModel:model reuseIdentifier:idenfireCell indexPath:indexPath tableView:tableView];
        NSLog(@"FormTableViewCell--%@",idenfireCell);
//        
//        cell=[[FormTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:idenfireCell];
//        [cell setupSubViewsForModel:model withIndexPath:indexPath andTableView:tableView];
    }

    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    [cell setupWithModel:model];

    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    FormModel * model=[self.dataSource objectAtIndex:indexPath.row];

    return model.cellHeight;
}

//自定义cell中的内容
-(FormBaseView*)tableView:(UITableView *)tableView atIndexPath:(NSIndexPath *)indexPath
{
//    return [TextFiledForm creat];
    
    return nil;
}
@end
