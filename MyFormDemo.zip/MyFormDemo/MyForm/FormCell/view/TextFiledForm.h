//
//  TextFiledForm.h
//  MyForm
//
//  Created by guolin     song on 2017/3/29.
//  Copyright © 2017年 eastraycloud. All rights reserved.
//

#import "FormBaseView.h"

@interface TextFiledForm : FormBaseView
+(instancetype)creat;
@end
